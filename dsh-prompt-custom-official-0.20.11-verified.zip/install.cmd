@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy RemoteSigned -File "%~dp0install.ps1" %*
set "rc=%ERRORLEVEL%"
echo.
pause
exit /b %rc%